# PHP Ecommerce | By Hasan Zamil Ahmed

An ecommerce web project using Object Oriented PHP, MySQL and Bootstrap

#### Setup Database
1. Go to localhost/phpmyadmin and create a database;
2. Name it "dbshop" and set collation to "utf8_unicode_ci";
3. Go to localhost/phpmyadmin and click "dbshop";
4. At the navigation menu, click "Import" and upload the dbshop.sql file in the same folder;

#### How to Navigate in Admin
1. In the browser's address bar, type localhost/ecommerce/admin/;
