 <div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; Copyright <a href="http://musical instrument.com"> </a>Touhid @cste_7th
        </p>
    </div>
</body>
</html>
