 <div class="search_box">
				    <form>
				    	<input type="text" value="Search for Products" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Search for Products';}"><input type="submit" value="SEARCH">
				    </form>
			    </div>
			    
			   ////
			   
			  		 <div class="header_bottom_right_images">
			<section class="slider">
				  <div class="flexslider">
					<ul class="slides">
						<li><img src="images/gibson-lp4-cherry.jpg" alt=""></li>
						<li><img src="images/gibson-2017-flying-v-t-ebony-3.jpg" alt=""/></li>
						<li><img src="images/boss-rc-30-loop-station.jpg" alt=""/></li>
						<li><img src="images/yamaha-mg16xu-2.jpg" alt=""/></li>
				    </ul>
				  </div>
	      </section>
 
	    </div>